#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

class Patient {
private:
    std::string name;
    int age;
    char gender;
    std::string diagnosis;
    std::string treatment;
    std::string medicalHistory;
    std::vector<std::pair<std::string, std::string> > labResults;

public:
    Patient(std::string n, int a, char g) : name(n), age(a), gender(g) {}

    // Setters
    void setDiagnosis(const std::string& d) { diagnosis = d; }
    void setTreatment(const std::string& t) { treatment = t; }
    void setMedicalHistory(const std::string& mh) { medicalHistory = mh; }
    void addLabResult(const std::string& test, const std::string& result) {
        labResults.push_back(std::make_pair(test, result));
    }

    // Getters
    std::string getName() const { return name; }
    int getAge() const { return age; }
    char getGender() const { return gender; }
    std::string getDiagnosis() const { return diagnosis; }
    std::string getTreatment() const { return treatment; }
    std::string getMedicalHistory() const { return medicalHistory; }
    std::vector<std::pair<std::string, std::string> > getLabResults() const { return labResults; }
};

class MedicalInfoSystem {
private:
    std::vector<Patient> patients;

public:
    void addPatient(const Patient& patient) {
        patients.push_back(patient);
    }

    bool deletePatient(const std::string& patientName) {
        for (vector<Patient>::iterator it = patients.begin(); it != patients.end(); ++it) {
            if (it->getName() == patientName) {
                patients.erase(it);
                return true;
            }
        }
        return false;
    }

    Patient* findPatient(const std::string& patientName) {
        for (size_t i = 0; i < patients.size(); ++i) {
            if (patients[i].getName() == patientName) {
                return &patients[i];
            }
        }
        return NULL;
    }
};

int main() {
    MedicalInfoSystem system;

    while (true) {
        cout << "1. Add Patient\n2. Find Patient\n3. Delete Patient\n4. Exit\n";
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;

        if (choice == 1) {
            string name;
            int age;
            char gender;

            cout << "Enter patient name: ";
            cin >> name;
            cout << "Enter patient age: ";
            cin >> age;
            cout << "Enter patient gender (M/F): ";
            cin >> gender;

            Patient newPatient(name, age, gender);
            system.addPatient(newPatient);

            cout << "Patient added successfully.\n";
        } else if (choice == 2) {
            string name;
            cout << "Enter patient name: ";
            cin >> name;

            Patient* patient = system.findPatient(name);
            if (patient) {
                cout << "Patient found!\n";
                cout << "Name: " << patient->getName() << "\n";
                cout << "Age: " << patient->getAge() << "\n";
                cout << "Gender: " << patient->getGender() << "\n";
            } else {
                cout << "Patient not found.\n";
            }
        } else if (choice == 3) {
            string name;
            cout << "Enter patient name to delete: ";
            cin >> name;

            if (system.deletePatient(name)) {
                cout << "Patient record deleted.\n";
            } else {
                cout << "Patient not found.\n";
            }
        } else if (choice == 4) {
            break;
        }
    }

    return 0;
}
